const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, message: 'Chưa đăng nhập' });
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'township_secret_2026');
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Token hết hạn' });
  }
};
